# Neon Kuş — Google Play'e Yükleme Rehberi (Termux'suz Yol)

Bu klasör, oyunu Termux'ta derlemeden, tamamen bulutta (Codemagic) Android
uygulamasına çevirip Google Play'e yüklemen için hazırlandı.

## 1) Google Play Console Hesabı Aç
1. https://play.google.com/console adresine git
2. Google hesabınla giriş yap, geliştirici kaydı için 25$ öde (tek seferlik, ömür boyu geçerli)
3. Kimlik doğrulaması istenebilir (bazen 24-48 saat sürer) — bunu en başta başlat, biz diğer adımları hazırlarken tamamlanır

## 2) GitHub Hesabı ve Repo
1. https://github.com adresinden ücretsiz hesap aç (yoksa)
2. Yeni bir repo oluştur: örn. `neon-kus`
3. Bu klasördeki tüm dosyaları (`www/`, `package.json`, `capacitor.config.json`, `codemagic.yaml`) o repoya yükle
   - Telefonda GitHub'ın kendi uygulaması veya mobil tarayıcıdan "Add file → Upload files" ile yapılabilir, Termux'a gerek yok

## 3) Codemagic Hesabı (Ücretsiz Bulut Derleme)
1. https://codemagic.io adresinden GitHub hesabınla giriş yap
2. Az önce oluşturduğun `neon-kus` reponu bağla
3. Codemagic, repodaki `codemagic.yaml` dosyasını otomatik tanır

## 4) İmzalama Anahtarı (Keystore)
Google Play'e yüklenecek her uygulamanın bir "imza anahtarı" olması gerekir.
- Codemagic üzerinden "Android code signing" bölümünden yeni bir keystore
  oluşturabilirsin (arayüzden, kod yazmadan)
- Bu keystore'u **kaybetme** — ileride güncelleme yüklemek için tekrar gerekecek

## 5) İlk Derleme
1. Codemagic'te "Start new build" de, `neonkus-android` workflow'unu seç
2. Derleme bitince bir `.aab` dosyası inecek (Android App Bundle)

## 6) Play Console'a Yükleme
1. Play Console'da "Uygulama oluştur" → isim: **Neon Kuş**
2. Store bilgileri: kısa açıklama, ekran görüntüleri (oyunu oynarken telefon
   ekran görüntüsü al, bunlardan 2-3 tane yeterli), uygulama ikonu (512x512 png)
3. "Production" veya önce "Internal testing" altına `.aab` dosyasını yükle
4. İçerik derecelendirmesi anketini doldur (basit oyun, sorun olmaz)
5. Gizlilik politikası linki iste — basit bir tane gerekiyor (istersen
   bir sonraki adımda bunu da senin için yazarım)
6. İncelemeye gönder (genelde birkaç saat–birkaç gün sürer)

## Notlar
- Paket adı: `com.neonkusgames.neonkus` — istersen değiştirebiliriz, ama
  **yükledikten sonra değiştirilemez**, bu yüzden şimdi karar vermek önemli
- Oyun dosyası `www/index.html` içinde — oyun mekaniğinde değişiklik
  istersen sadece bu dosyayı güncelleyip tekrar derletmen yeterli
